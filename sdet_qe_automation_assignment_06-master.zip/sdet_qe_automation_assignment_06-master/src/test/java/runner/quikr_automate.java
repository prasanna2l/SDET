package runner;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class quikr_automate {
		//@Test1-Automation for login-register
		WebDriver driver;
		@Given("^User Launch the Browser$")
		public void User_Launch_the_Browser() 
		{
			System.setProperty("webdriver.chrome.driver","D:\\sdet_module 3\\chromedriver.exe");
			driver=new ChromeDriver();
			driver.manage().window().maximize();
		}
		@When("^User Enter Url of quikr$")
		public void user_Enter_Url_of_quikr() 
		{
			driver.get("https://www.quikr.com/");
		}
		@And("^Click on The button login_Register$")
		public void Click_on_The_button_login_Register() 
		{
			driver.findElement(By.xpath("//*[@id='loginLink']/span/label")).click();
		}
		@And("User Should Give his email {String}")
		public void User_Should_Give_his(String email) 
		{
			driver.findElement(By.xpath("/html/body/div[3]/div[1]/div[1]/div/div/div/div/form/div[1]/div/input")).sendKeys(email);
		}
		@And("^User Should Click continue button$")
		public void User_Should_Click_continue_button() throws InterruptedException 
		{
			driver.findElement(By.xpath("//*[@id=\"newLoginSignUpModal\"]/div/div/div/div/form/div[2]/button")).click();
			Thread.sleep(20000);
		}
		@And("User Should enterr password{String}")
		public void User_Should_enterr(String password) 
		{
			driver.findElement(By.xpath("/html/body/div[3]/div[1]/div[1]/div/div/div/div/form/div[1]/div[2]/input")).sendKeys(password);
		}
		@And("^User Should Click login button$")
		public void User_Should_Click_login_button() throws InterruptedException 
		{
			driver.findElement(By.xpath("//*[@id=\"newLoginSignUpModal\"]/div/div/div/div/form/div[2]/button")).click();
			Thread.sleep(20000);
		}
		@Then("^User is Successfully logged in and Get Title of Page$")
		public void User_is_Successfully_logged_in_and_Get_Title_of_page() 
		{
			System.out.println("Title of Page----------"+driver.getTitle());
			driver.close();
		}
		
		//@Test2-Automation for searching an item
		@When("^user Click on Search in all India$")
		public void User_click_on_Search_in_all_India() throws InterruptedException 
		{
			driver.findElement(By.xpath("//*[@id=\"query\"]")).click();
			Thread.sleep(20000);
		}
		@And("^User Should enter bikes on search box$")
		public void User_Should_enter_bikes_on_search_box() 
		{
			driver.findElement(By.xpath("/html/body/header/div/div[2]/div[1]/div[3]/div[1]/div[2]/form/input[1]")).sendKeys("bikes");
		}
		@Then("^user_will_Be_Successfully_get_into_the_Menu_and_done_work$")
		public void user_will_Be_Successfully_get_into_the_Menu_and_done_work() 
		{
			System.out.println("Landed on page");
			driver.close();
		}
		//@Test3-Automation for Buying an item
		@Given("^User_get_back_to_the_homepage$")
		public void User_get_back_to_the_homepage() 
		{
			driver.navigate().to("https://www.quikr.com/");
		}
		@And("^user_click_on_Electronics_and_appliances$")
		public void user_click_on_Electronics_and_appliances() 
		{
			driver.findElement(By.xpath("//*[@id=\"rightContainer\"]/div[3]/div/div[1]/div/a[2]")).click();
		}
		@And("^user click on Washing machine$")
		public void user_click_on_Washing_machine() 
		{
			driver.findElement(By.xpath("//*[@id=\"assured-cats-slider\"]/div[1]/div/div[4]/li/a/img")).click();
		}
		
		@And("User Should enter {String}")
		public void User_Should_enter(String pincode)
		{
			driver.findElement(By.xpath("//*[@id=\"user-pincode\"]")).sendKeys(pincode);
		}
		@And("^user need to click on submit$")
		public void user_need_to_click_on_submit() 
		{
			driver.findElement(By.className("mdc-button mdc-button--primary")).click();
		}
		@And("^user need to click on view button of product$")
		public void user_need_to_click_on_view_button_of_product() 
		{
			driver.findElement(By.xpath("/html/body/div[7]/div[1]/div[2]/div/div[2]/div/div[4]/div[2]/div/div[1]/div/a/div/section[2]/div[2]/ul/li[3]/button")).click();
		}
		@And("^user need to click on chat to buy$")
		public void user_need_to_click_on_chat_to_buy() 
		{
			driver.findElement(By.className("sc-ldbotn-0 hdNuPA sc-1a3uvr7-1 bHnDrL fwB bt1")).click();
		}
		@Then("^user will Be Successfully get the poster connect and done work$")
		public void user_will_Be_Successfully_get_the_poster_connect_and_done_work() 
		{
			System.out.println("SUCCESSFULLY CONNECTED TO POSTER CONNECT");
			driver.close();
		}	

}
