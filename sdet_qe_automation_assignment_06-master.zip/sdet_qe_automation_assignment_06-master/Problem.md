Cucumber-Selenium Assignment:

Automate any of the following url using Cucumber BDD framework.

Try to automate the testing for any of 3 major functionality like registration,login and any one major menu item of the particular web site.

https://www.quikr.com/
https://www.facebook.com
https://www.airbnb.co.in/
https://www.zomato.com/
https://www.uber.com/in/en/
https://www.monsterindia.com/
https://www.shaadi.com/
