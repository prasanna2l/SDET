Install amazon application mobile emulator

You should do the followings -
1. You should use cucumber framework
2. Write scenarios for Amazon login functionality
3. There should be minimum 5 scenarios
4. Generate cucumber allure report

Your scripts must use -
1. Cucumber framework
2. Write Cucumber scripts
3. Your code should generate reports
4. There should be minimum 5 test cases.

How to submit the Assessment -
1. Create a git repo and maven project
2. Push the project code into the remote git repo
3. Give your mentor "Developer" access of your git repo
4. Share the git repo with your mentor using slack
