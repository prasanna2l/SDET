package runner;
import org.testng.annotations.Test;

import io.cucumber.testng.AbstractTestNGCucumberTests;


@Test
@io.cucumber.testng.CucumberOptions(
		features = "resources/amazon.feature",
        glue="stepDefinition",
        plugin= {"pretty","io.qameta.allure.cucumber6jvm.AllureCucumber6Jvm",
        		 "html:target/cucumber-reports"
        		}
		)
public class test_runner extends AbstractTestNGCucumberTests{
}