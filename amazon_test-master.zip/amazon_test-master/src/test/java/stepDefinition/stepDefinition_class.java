package stepDefinition;

import static org.testng.Assert.assertEquals;
import java.io.IOException;

import org.testng.annotations.Test;

import androidAction.actionClass;
import capabilitySetup.desiredCapability;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class stepDefinition_class extends desiredCapability {
	
	actionClass page = new actionClass(driver);
	
	@Given("you are on the Login Page of Amazon app")
	public void you_are_on_the_login_page_of_amazon_app() {
		// android setup will launch Amazon
		driver.get("https://www.amazon.in/");
		System.out.println("Started Amazon app..");
	}

	@When("Email field is Empty")
	public void email_field_is_empty() {
		page.getEnterUserId("12");
		page.clickContinueBtn();
	}

	@Then("should give message, Enter your email or mobile phone number")
	public void should_give_message_enter_your_email_or_mobile_phone_number() {
		assertEquals(page.getmsg(),"enter email or mobile number");
	}

	@When("user Enters email and clicks on Continue")
	public void user_enters_email_and_clicks_on_continue() {
		page.getEnterUserId("prasannabharanipsl@gmail.com");
		page.clickContinueBtn();
	}

	@Then("should display page to enter password")
	public void should_display_page_to_enter_password() {
		String title = page.getTitle();
		System.out.println(title);
	}

	@When("user Enters wrong phone number and clicks on Continue")
	public void user_enters_wrong_phone_number_and_clicks_on_continue() {
		page.getEnterUserId("789654");
		page.clickContinueBtn();
	}

	@Then("should give message, No account found with mobile number")
	public void should_give_message_no_account_found_with_mobile_number() {
		assertEquals(page.getmsg(),"No accounts found with this mobile number");
	}

	@When("user Enters wrong email address and clicks on Continue")
	public void user_enters_wrong_email_address_and_clicks_on_continue() {
		page.getEnterUserId("me.mlksdf");
		page.clickContinueBtn();
	}

	@Then("should give message, No account found with email address")
	public void should_give_message_no_account_found_with_email_address() {
		assertEquals(page.getmsg(),"No accounts found with this email");
	}

	@Given("you are on the Sign in Page of Amazon app")
	public void you_are_on_the_sign_in_page_of_amazon_app() {
		throw new io.cucumber.java.PendingException();
	}

	@When("user enters password and clicks on Sign in")
	public void user_enters_password_and_clicks_on_sign_in() {
		page.EnterPassword("prasanna@123");
		page.clickLogInBtn();
	}

	@Then("User is redirected to Home Page of Amazon")
	public void user_is_redirected_to_home_page_of_amazon() {
		String homePage_title = page.getTitle();
		System.out.println(homePage_title);
	}
}

