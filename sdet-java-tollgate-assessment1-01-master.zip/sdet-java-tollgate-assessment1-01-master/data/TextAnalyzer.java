//Text Analyzer - Java Hackathon
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

//class word
public class Word {
	private String option;
	private String fileName;

//used to store details of a word that is read from a text file
	public Word() {
		option = "-a";
		fileName = "daffodils.txt";
	}
	public String getOption() {
		return option;
	}
	public void setOption(String option) {
		this.option = option;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public Word(String[] args) {
		this();
		if (args.length == 2) {
			option = args[0];
			fileName = args[1];
		}
	}

	//store the number of times
	public void analyzeText() throws IOException {
		switch (option) {
		case "-a":
			System.out.println("No. of lines in file: " + getLineCount());
			System.out.println("No. of words in file: " + getWordCount());
			System.out.println("No. of characters in file: " + getCharacterCount());
			break;
		case "-l":
			System.out.println("No. of lines in file: " + getLineCount());
			break;
		case "-w":
			System.out.println("No. of words in file: " + getWordCount());
			break;
		case "-c":
			System.out.println("No. of characters in file: " + getCharacterCount());
			break;
		default:
			break;
		}
	}

	public int getCharacterCount() throws IOException {
		int count = 0;
		List<String> list = readFileIntoList();
		for (String line : list) {
			count += line.length();
		}
		return count;

	}

	public int getWordCount() throws IOException {
		int count = 0;
		List<String> list = readFileIntoList();
		Pattern pattern = Pattern.compile("[ ]");
		for (String line : list) {
			String[] words = pattern.split(line);
			count += words.length;
		}
		return count;
	}

	public int getLineCount() throws IOException {
		List<String> list = readFileIntoList();
		return list.size();
	}

	public List<String> readFileIntoList() throws IOException {
		List<String> list = new ArrayList<>();
		try (BufferedReader bufferedReader = new BufferedReader(new FileReader(fileName))) {
			String line = "";
			while ((line = bufferedReader.readLine()) != null) {
				list.add(line);
			}
		} catch (IOException e) {
			throw e;
		}
		return list;
	}
}

    {       
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter any sentence below : ");
        String text = sc.nextLine();
        String[] keys = text.split(" ");
        String[] uniqueKeys;
        int count = 0;
        
        uniqueKeys = getUniqueKeys(keys);

        for(String key: uniqueKeys)
        {
            if(null == key)
            {
                break;
            }           
            for(String s : keys)
            {
                if(key.equals(s))
                {
                    count++;
                }               
            }
            System.out.println("Count of [ "+key+" ] is : "+count);
            count=0;
        }
    }

    private static String[] getUniqueKeys(String[] keys)
    {
        String[] uniqueKeys = new String[keys.length];

        uniqueKeys[0] = keys[0];
        int uniqueKeyIndex = 1;
        boolean keyAlreadyExists = false;

        for(int i=1; i<keys.length ; i++)
        {
            for(int j=0; j<=uniqueKeyIndex; j++)
            {
                if(keys[i].equals(uniqueKeys[j]))
                {
                    keyAlreadyExists = true;
                }
            }           

            if(!keyAlreadyExists)
            {
                uniqueKeys[uniqueKeyIndex] = keys[i];
                uniqueKeyIndex++;               
            }
            keyAlreadyExists = false;
        }       
        return uniqueKeys;
    }
}