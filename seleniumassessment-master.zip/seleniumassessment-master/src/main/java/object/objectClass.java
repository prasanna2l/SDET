package object;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class objectClass {
	@FindBy(xpath="//*[@id=\"app\"]/div/div/div[2]/div/div[1]/div/div[2]/svg")
	public WebElement element_click; 
	
	@FindBy(xpath="//*[@id=\"item-1\"]")
	public WebElement chk_box; 
	
	@FindBy(xpath="//*[@id=\"tree-node\"]/ol/li/span/label/span[1]/svg")
	public WebElement chk_box_tick; 
	
	@FindBy(xpath="//*[@id=\"item-6\"]/span")
	public WebElement brokenLink;
}
