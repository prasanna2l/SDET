package action;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import object.objectClass;

public class actionClass {
	public static WebDriver driver;
	objectClass set = PageFactory.initElements(driver,objectClass.class);
	
	public void browser_launching() {
		System.setProperty("webdriver.chrome.driver","D:\\sdet_module 3\\102_chromedriver\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("https://demoqa.com/");
		}
	
	public void elements_click () {
		set.element_click.click();
	}
	
	public void chk_box() {
		set.chk_box.click();
	}
	
	public void chk_box_tick() {
		set.chk_box_tick.click();
	}
	//driverBack
	public void driverBack() {
		driver.navigate().to("https://demoqa.com/");
	}
	
	public void broken_link() {
		set.brokenLink.click();
	}
	
}