package action;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class testNG {
	WebDriver driver;
	@BeforeTest
	public void open() {
		System.setProperty("webdriver.chrome.driver", "D:\\sdet_module 3\\102_chromedriver\\chromedriver.exe");
    	driver = new ChromeDriver();
	}
	
	@Test(priority = 1)
	public void url_opening() {
		driver.get("https://demoqa.com/");
	}
	
	@Test(priority = 2)
	public void maximizing() {
		driver.manage().window().maximize();
	}
	
	@Test(priority = 3)
	public void page_title() {
		String title = driver.getTitle();
		System.out.println(title);
	}
	
	@Test(priority = 4)
	public void checking_page() {
		String str = driver.getCurrentUrl();
		String str_actual = "https://demoqa.com/elements";
		if(str==str_actual) {
			System.out.println("we get the desired page");
		}else {
			System.out.println("we NOT get the desired page");
		}
	}
	
	@Test(priority = 5)
	public void homepage_navigation() {
		driver.navigate().to("https://demoqa.com/");
		System.out.println("Navigated back to homepage");
	}
	
	@AfterTest
	public void submit() {
    	driver.close();
	}

}
