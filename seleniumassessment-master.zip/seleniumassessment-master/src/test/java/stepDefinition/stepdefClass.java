package stepDefinition;

import java.util.concurrent.TimeUnit;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class stepdefClass {
	WebDriver driver;
	
	@Given("^opening webbrowser$")
	public void open() {
		System.setProperty("webdriver.chrome.driver", "D:\\sdet_module 3\\102_chromedriver\\chromedriver.exe");
    	driver = new ChromeDriver();
	}
	
	@When("$User enter into Url^")
	public void url() {
		driver.get("https://demoqa.com/");
	}
	
	@When("$User navigate to element^")
	public void element() {
		driver.findElement(By.xpath("//*[@id=\\\"app\\\"]/div/div/div[2]/div/div[1]/div/div[2]/svg")).click();
	} 
	
	@When("$User navigate to formfilling^")
	public void form() {
		driver.findElement(By.xpath("//*[@id=\"app\"]/div/div/div[2]/div[1]/div/div/div[2]/span/div/div[1]")).click();
	} 
	
	@When("$User navigate to practice_form^")
	public void form_practice() {
		driver.findElement(By.xpath("//*[@id=\"item-0\"]/span")).click();
	} 
	
	@When("$User enter Fname^")
	public void fname() {
		driver.findElement(By.id("firstName")).sendKeys("prasanna");
	} 
	
	@When("$User enter Lname^")
	public void lname() {
		driver.findElement(By.id("lastName")).sendKeys("y");
	} 
	
	@When("$User enter number^")
	public void num() {
		driver.findElement(By.id("userNumber")).sendKeys("1236547890");
	} 
	
	@When("$User choose gender^")
	public void gender() {
		driver.findElement(By.xpath("//*[@id=\"genterWrapper\"]/div[2]/div[1]/label")).click();
	} 
	
	@When("$User click submit^")
	public void submit() {
		driver.findElement(By.id("submit")).click();
	} 
}

	
