package action;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import obj.ObjPage;

public class actionPage {
	
	public static WebDriver driver;
	ObjPage set = PageFactory.initElements(driver,ObjPage.class);
	
	public void initialsignup () {
		set.Sign.click();
	}
	public void skone(String a,String b) {
		set.FullName.sendKeys(a);
		set.EMail.sendKeys(b);
	}
	
	public void clicking() {
		set.chkbox.click();
		set.createacc.click();
	}
	public void login() {
		set.login.click();
		set.email_click.click();
		set.emailbox_click.click();
	}
	public void sktwo(String c) {
		set.inputting_email.sendKeys(c);
	}
	public void clthree() {
		set.otp.click();
		set.proceed.click();
	}
	public void action() {
		set.order.click();
	}
}