package StepDefs;

import action.actionPage;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;

public class ladder {
	actionPage act = new actionPage();
	
	@When("user navigate to application url {string}")
	public void user_navigate_to_application_url(String url) {
		Hooks.driver.get(url);
	}

	@And("user enter contact initialsignup")
	public void user_enter_contact_initialsignup() { 
		act.initialsignup();  
	}
	
	@And("user enter skone {String Fullnamee},{String Emaill}")
	public void user_enter_skone(String FullNamee, String EMaill) {
		act.skone(FullNamee,EMaill);
	}

	@And("user done clicking")
	public void user_done_clicking() {
		act.clicking();
	}

	@And("user enter login")
	public void user_enter_login() {
		act.login();
		
	}
	@And("user enter sktwo {String inputemailss}")
	public void user_enter_sktwo (String inputemailss) {
		act.sktwo(inputemailss);	
	}
	
	@And("user done clthree")
	public void user_done_clthree() {
		act.clthree();
	}

	@And("user enter action")
	public void user_enter_action() {
		act.action();
	}

}
