package StepDefs;

import org.openqa.selenium.chrome.ChromeDriver;

import action.actionPage;
import io.cucumber.java.After;
import io.cucumber.java.Before;

public class Hooks extends actionPage{
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver","D:\\sdet_module 3\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		
	}
	@After
	public void tearDown() {
		driver.close();
	}

}
