package runner;

import org.junit.runner.RunWith;
import org.testng.annotations.Test;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import io.cucumber.testng.AbstractTestNGCucumberTests;

//@RunWith(Cucumber.class) 
@Test
@io.cucumber.testng.CucumberOptions(
		features= "resource/PageAuto.feature", 
		glue="StepDefs",
		plugin= {"pretty","io.qameta.allure.cucumber6jvm.AllureCucumber6Jvm"}
		//plugin={"html:target/cucumber-reports" }
		)
public class TestRunner extends AbstractTestNGCucumberTests{
}
