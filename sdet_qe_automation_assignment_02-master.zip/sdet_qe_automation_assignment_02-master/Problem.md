### Selenium Automation

Amazon.in Website automation

    Steps to Automate:
    1. Launch browser of your choice say., firefox, chrome etc.
    2. Open this URL -  www.amazon.in
    3. Maximize or set size of browser window.
    4. Get the page title and print it.
    5. Click on first menu link, say 'Amazon Pay'.
    6. Get Page title and verify it with expected value.
    7. Navigate back to Home Page. 
    8. Get Page title and verify it with expected value.
    9. Repeat steps 5 to 8 for other menu links.
    10. Close the browser.

    Note: Use Synchronization and Javascript Executor

