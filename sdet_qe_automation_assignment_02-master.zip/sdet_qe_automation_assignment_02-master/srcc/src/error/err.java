package error;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
//prasanna_22sdet_qe_automation_assignment_02

@SuppressWarnings("unused")
public class err {
	public static void main(String[] args) throws Throwable {
		System.setProperty("webdriver.chrome.driver","D:\\sdet_module 3\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		String newline = System.getProperty("line.separator");
		driver.get("https://www.amazon.in/");
		driver.manage().window().maximize();
		Thread.sleep(1000);
		String t = driver.getTitle();
		System.out.println("Getting Page Title : "+t+newline);
		WebElement elm = driver.findElement(By.cssSelector("a[href*='nav_cs_apay']"));
		//String s = elm.getTitle();
	    System.out.println("Title of amazon pay : "+newline);
	    System.out.println(driver.getTitle());
	    //Thread.sleep(1000);
		String t1=driver.getTitle();
		String Expected = "Amazon Pay";
		if(driver.getTitle().equalsIgnoreCase(Expected)) {
			System.out.println("Title Matching with Excepted Value for amazon pay!"+newline);
		}else
		{
			System.out.println("Title Not Matching with excepted value for amazon pay!"+newline);
		}
		driver.navigate().back();
		System.out.println("Navigating to home page.."+newline);
		String Expected2 = "Online Shopping site in India: Shop Online for Mobiles, Books, Watches, Shoes and More - Amazon.in";
		if(t.equalsIgnoreCase(Expected2)) {
			System.out.println("After navigating back , Title Matching with Excepted Value!"+newline);
		}else
		{
			System.out.println("After navigating back Title Not Matching with excepted value!"+newline);
		}
		System.out.println("Repeating steps..for other menu"+newline);
		driver.navigate().to("https://www.amazon.in/Home-Kitchen/b/?ie=UTF8&node=976442031&ref_=nav_cs_home");
		String t2 = driver.getTitle();
		String Exp_2 = "Home Store: Buy Home & Kitchen products online at best prices in India - Amazon.in";
		if(t2.equals(Exp_2)) {
			System.out.println("Menu 2(Home&Kitchen) will match with excepted value"+newline);
		}
		else {
			System.out.println("Menu 2(Home&Kitchen) will not match with excepted value"+newline);
		}
		driver.get("https://www.amazon.in/");
		System.out.println("Navigated to home page for validating title.."+newline);
		String exp_4 = "Online Shopping site in India: Shop Online for Mobiles, Books, Watches, Shoes and More - Amazon.in\r\n";
		if(t.equals(exp_4)) {
			System.out.println("After navigating Title Matching with Excepted Value!");
		}else {
			System.out.println("After navigating Title not Matching with Excepted Value!");
		}
		driver.close();

	}

}

