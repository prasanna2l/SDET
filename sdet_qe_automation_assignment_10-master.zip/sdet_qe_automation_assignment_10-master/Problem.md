### JMeter Assignment

    # Complete the performance testing for blazedemo.com

        Check for registartion and login functionality of this page.
        Increase the no of users for 100, then to 200 and then to 300, setting the Rampup period as 300 seconds 
                and Loop count as 1.
        Use user defined variables for registration and login functionality
        For report generation use View results in tree and View Results in table and analyse

    Use this ref link: https://www.blazemeter.com/blog/fill-forms-and-submit-with-jmeter-made-easy

    # Complete the database connection testing in Jmeter.

        Use config element->JDBC Connection configuration for connecting to Mysql database table
        use sampler->JDBC request for making a simple select query from any table
        Generate the report using View Results in tree

