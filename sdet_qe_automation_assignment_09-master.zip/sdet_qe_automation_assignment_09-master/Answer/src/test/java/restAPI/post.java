package restAPI;

import org.json.JSONObject;
import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class post {

	public static void main(String[] args) {
		// 1.Add a Product: http://localhost:8082/productservice/addProduct
		RestAssured.baseURI = "http://localhost:8082/productservice/addProduct";
		RequestSpecification http_request = RestAssured.given().log().all();
		//creating req in json
		JSONObject jsob = new JSONObject();
		jsob.put("productName","abc");
		jsob.put("productDescription","xyz");
		jsob.put("productPrice",65.2);
		jsob.put("productId",12);
		//jsob.put("","");
		//header-adding
		http_request.header("Content-Type","application/json");//header("Accept","data/json");
		http_request.body(jsob.toString());
		//posting header,cont
		Response res = http_request.request(Method.POST);
		System.out.println("Status code : "+res.getStatusCode());
		System.out.println("Body "+res.getBody().asPrettyString());
	}
}