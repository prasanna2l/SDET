package restAPI;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import junit.framework.Assert;

public class Get_all {

	public static void main(String[] args) {
		// 5.Get all products :http://localhost:8082/productservice/products
		RestAssured.baseURI = "http://localhost:8082/productservice/products";
		RequestSpecification http_request = RestAssured.given().log().all();//uri();
		Response response_request = http_request.request(Method.GET);
		int StatusCode = response_request.getStatusCode();
		System.out.println("Status"+StatusCode);
		System.out.println("Response"+response_request.getBody().asPrettyString());
		//junit framework 
		Assert.assertEquals(StatusCode,200);
		System.out.println("Assert Passed");
	}
}