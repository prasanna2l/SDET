package restAPI;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class get {

	public static void main(String[] args) {
		// 2.Get a product by Id: http://localhost:8082/productservice/{productId}
		RestAssured.baseURI = "http://localhost:8082/productservice/products";
		RequestSpecification http_request = RestAssured.given().log().all();
		Response response_request = http_request.request(Method.GET);
		int StatusCode = response_request.getStatusCode();
		System.out.println("Status"+StatusCode);
		System.out.println("Response"+response_request.getBody().asPrettyString());
	}
}