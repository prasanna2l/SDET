package restAPI;

import org.json.JSONObject;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class put {

	public static void main(String[] args) {
		// 3.Update a product : http://localhost:8082/productservice/{productId}
		RestAssured.baseURI = "http://localhost:8082/productservice/12";
		RequestSpecification http_request = RestAssured.given().log().all();//uri();
		//creating req in json
		JSONObject jsob = new JSONObject();
		jsob.put("productName","restAPI");
		//jsob.put("","");
		//header-adding
		http_request.header("Content-Type","application/json");
		http_request.body(jsob.toString());
		//posting header,cont
		Response res = http_request.request(Method.PUT);
		System.out.println("Status code "+res.getStatusCode());
		System.out.println("Body "+res.getBody().asPrettyString());
	}
}