### Selenium with TestNG Automation

#### Automate User Registration process

    Steps to Automate:
    1. Open this url  http://automationpractice.com/index.php
    2. Click on sign in link.
    3. Enter your email address in 'Create and account' section.
    4. Click on Create an Account button.
    5. Enter your Personal Information, Address and Contact info.
    6. Click on Register button.
    7. Validate that user is created.
    Note: Use assert statements for validations


#### Automate a demo About Me form. Form contains all the basic web elements so it will cover all basic webdriver commands.

    Steps to automate:
    Open this link - https://www.techlistic.com/p/selenium-practice-form.html
    Enter first and last name (textbox).
    Select gender (radio button).
    Select years of experience (radio button).
    Enter date.
    Select Profession (Checkbox).
    Select Automation tools you are familiar with (multiple checkboxes).
    Select Continent (Select box).
    Select multiple commands from a multi select box.
    If you can handle Upload image then try it or leave this step.
    Click on Download file link and handle the download file pop-up (leave it if you are beginner)
    Click on Submit button.

