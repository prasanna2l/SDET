package test;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.AfterClass;

public class tester {
	WebDriver driver;
	
	//@Test(priority=1)
	@BeforeTest
	public void testSetup()
	{
	System.setProperty("webdriver.chrome.driver", "D:\\sdet_module 3\\chromedriver.exe");
	driver=new ChromeDriver();
	driver.manage().window().maximize();
	System.out.println("Set-up successful");

	}

	//@Test(dependsOnMethods={"testSetup"})
	@Test
	public void openBrowser() {
		driver.get("http://automationpractice.com/index.php");
		driver.findElement(By.xpath("//*[@id=\"header\"]/div[2]/div/div/nav/div[1]/a")).click();
		System.out.println("Browser running successfully..");
		
	}
	
	@Test(groups="b")
	public void register() throws InterruptedException {
		driver.findElement(By.id("email_create")).sendKeys("prasannabharanipsl@gmail.com");
		WebElement e = driver. findElement(By.name("SubmitCreate"));
		e.click();
		Thread.sleep(3000);
		System.out.println("Submitted Email");
	}
	
	@Test(groups="c")
	public void prsnl_info() {
		driver.findElement(By.id("customer_firstname")).sendKeys("Prasanna");
		driver.findElement(By.id("customer_lastname")).sendKeys("Y");	
		driver.findElement(By.id("passwd")).sendKeys("09876poiuy");
		Select dropdown_D = new Select(driver.findElement(By.id("days")));
		dropdown_D.selectByValue("13");
		Select dropdown_M = new Select(driver.findElement(By.id("months")));
		dropdown_M.selectByValue("4");
		Select dropdown_Y = new Select(driver.findElement(By.id("years")));
		dropdown_Y.selectByValue("2001");
		driver.findElement(By.id("firstname")).sendKeys("Prasanna");
		driver.findElement(By.id("lastname")).sendKeys("Y");
		driver.findElement(By.id("address1")).sendKeys("Selenium Framework, Research Triangle Park, North ABC,TN");
		driver.findElement(By.id("city")).sendKeys("xyz");
		Select dropdown = new Select(driver.findElement(By.id("id_state")));
		dropdown.selectByValue("40");
		driver.findElement(By.xpath("//*[@id=\"postcode\"]")).sendKeys("12345");
		driver.findElement(By.id("phone_mobile")).sendKeys("1234567890");
		driver.findElement(By.id("alias")).sendKeys("Selenium Framework, Research Triangle Park, North ABC,TN");
		System.out.println("credentials passed");
	}
		//credentials submitting
		@Test(dependsOnGroups = "c")
		public void Final_Register() {
			driver.findElement(By.xpath("//*[@id=\"submitAccount\"]/span")).click();
		}
		
		@Test (dependsOnMethods={"Final_Register"})
		public void post_Reg() {
			System.out.println(driver.getCurrentUrl());
			String exp = "http://automationpractice.com/index.php?controller=my-account";
			String s=driver.getCurrentUrl();
			String Actual = s;
			int c = 0;
			if(exp==Actual) {
				c+=1;
			}else {
				c+=5;
			}
			try {
			Assert.assertEquals("1","1");
			System.out.println("-----------User accout created------------");
			}catch(Exception e) {
				System.out.println("Unable to Validate..");
			}
			}
		
		@AfterTest
		public void afterClass() {
			driver.quit();
		}

}
