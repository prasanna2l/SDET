package runner;

import org.testng.annotations.Test;

import io.cucumber.testng.AbstractTestNGCucumberTests;
//@RunWith(Cucumber.class)
@Test
@io.cucumber.testng.CucumberOptions
(
		features = "feature/quikr.feature",
        glue="stepDefinition",
        plugin= {"pretty","io.qameta.allure.cucumber6jvm.AllureCucumber6Jvm"}
        //plugin = {"html:target/cucumber-reports" }
		)
public class RunnerQuikr extends AbstractTestNGCucumberTests {

}
