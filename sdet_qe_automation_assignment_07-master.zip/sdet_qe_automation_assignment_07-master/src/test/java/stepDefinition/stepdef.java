package stepDefinition;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class stepdef {
	WebDriver driver;
	@Given("User Launch the Browser")
	public void user_Launch_the_Browser() {
		System.setProperty("webdriver.chrome.driver","D:\\sdet_module 3\\102_chromedriver\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().window().maximize();
	    
	}

	@When("User gets Url of quikr")
	public void url_getting() {
		driver.get("https://www.quikr.com/");
	    
	}
	
		@When("User navigate to elec and app")
	public void user_navigation() {
		driver.findElement(By.xpath(" //*[@id='rightContainer']/div[3]/div/div[1]/div/a[2] " )).click();
	}
	
	@When("User Should enter to all elect")
	public void user_click_allelec() {
	driver.findElement(By.xpath("//*[@id=\"assured-cats-slider\"]/div[1]/div/div[1]/li/a/img")).click();
	driver.quit();
	}
	
}