
### Cucumber Allure Report Assignment


    Generate Allure report for the assignment

    https://gitlab-wipro.stackroute.in/sdet_qe_manual_automation_assignments/sdet_qe_automation_assignment_06
