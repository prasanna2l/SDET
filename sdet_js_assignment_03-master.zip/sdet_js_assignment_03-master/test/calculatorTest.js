const{add,sub,mul,div}=require("../calculator");
const except=require('chai').expect

//BDD-Mocha-describe,it
describe("    S U I T E - 1 (mocha)", function(){
	it("MochaTest_1",function(){
		console.log("Add : "+add(2,3))
		}
		)
		it("MochaTest_2",function(){
			console.log("Sub : "+sub(5,2))
		})
		it("MochaTest_3",function(){
			console.log("Mul : "+mul(5,2))
		})
		it("MochaTest_4",function(){
			console.log("Div : "+div(6,2))
		})
		})
		
//Chai-describe,it,except
describe("    S U I T E - 2 (chai)",function(){
	it("ChaiTest_1",function(){
		except(add(2,3)).to.be.equal(5)
		}
		)
		it("ChaiTest_2",function(){
			except(sub(5,2)).to.be.equal(3)
		})
		it("ChaiTest_3",function(){
			except(mul(5,2)).to.be.equal(10)
		})
		it("ChaiTest_3",function(){
			except(div(6,2)).to.be.equal(3)
		})
		})