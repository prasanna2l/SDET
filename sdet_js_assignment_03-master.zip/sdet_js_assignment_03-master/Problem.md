### Testing JavaScript Code - Assignment

### Use Mocha and Chai


    Steps to follow:
    1. Create a Javascript file by name "Calculator"
    2. Have methods for addition, subtraction, multiplication and division
    3. Create a Test file by name "CalculatorTest"
    4. Test all the methods of Calculator.js using Mocha & Chai
