//Amazon page automation
describe ("End to End Testing of SPA",function(){
	it("steps to automate",function(){
		
		//1. Launch the chrome browser-done from cypress 
		//2. Open this URL -  www.amazon.in
		cy.visit("https://www.amazon.in/");
		
		//3. Maximize or set size of browser window
		cy.viewport(1519, 746)
		
		//4. Get the page title and printing it
		let tit = cy.title()//tit in console
		cy.wait(2000)
		
		//5. Click on first menu link, say 'Amazon Pay'
		cy.get('[data-csa-c-content-id="nav_cs_apay"]').click()
		cy.wait(1000)
		
		//6. Get Page title and verify it with expected value
		//const tit1 = cy.title()
		cy.log("Title of Amazon Pay page : " ,cy.title().should('eq', 'Amazon Pay'))
		console.log("Title Matched..!")
		cy.wait(1000)
		
		//7. Navigate back to Home Page. 
		cy.go('back')
		cy.wait(1000)
		
		//8. Get Page title and verify it with expected value
		cy.title().should('eq', 'Online Shopping site in India: Shop Online for Mobiles, Books, Watches, Shoes and More - Amazon.in')
		cy.wait(1000)
	});
});
		
		
describe ("Repeating steps for other menu links",function(){
	it("steps to automate for other links",function(){
		//9. Repeat steps 5 to 8 for other menu links
		cy.get('[data-csa-c-content-id="nav_cs_books"]').click()
		cy.wait(1000)
		cy.log("Title of Amazon Books page : " ,cy.title().should('eq', 'Book Store Online : Buy Books Online at Best Prices in India | Books Shopping @ Amazon.in'))
		cy.go('back')
		
		//for other menu links
		cy.get('[data-csa-c-content-id="nav_cs_help"]').click()
		cy.wait(1000)
		cy.log("Title of Customer service page : " ,cy.title().should('eq', 'Help - Amazon Customer Service'))
		cy.go('back')
		
		cy.get('[data-csa-c-content-id="nav_cs_mobiles"]').click()
		cy.wait(1000)
		cy.log("Title of Mobiles page : " ,cy.title().should('eq', 'Mobile Phones: Buy New Mobiles Online at Best Prices in India | Buy Cell Phones Online - Amazon.in'))
		cy.go('back')
		
		cy.get('[data-csa-c-content-id="nav_cs_fashion"]').click()
		cy.wait(1000)
		cy.log("Title of Fashion page : " ,cy.title().should('eq', 'Amazon Fashion: Clothing, Footwear and Accessories online for Men, Women and Kids'))
		cy.go('back')
		
		cy.get('[data-csa-c-content-id="nav_cs_gb"]').click()
		cy.wait(1000)
		cy.log("Title of TodayDeals page : " ,cy.title().should('eq', "Amazon.in - Today's Deals"))
		cy.go('back')
		
		//10. Close the browser
		cy.end()
	});
});