/* Write a Program to Flatten a given n-dimensional array */
let input = [1, [2, 3], [[4], [5]]];
let output = [];
const flatten = (input) => {
	input.forEach(e => {
        if (Array.isArray(e)) {
            flatten(e)
        } else {
            output.push(e);
        }
        console.log(e);
    });
    return output
flatten(input);
console.log(output);
	// Write your code here
};

/* For example,
INPUT - flatten([1, [2, 3], [[4], [5]])
OUTPUT - [ 1, 2, 3, 4, 5 ]

*/

module.exports = flatten;
