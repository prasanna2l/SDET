// Create a list of fruits with their properties (name, color, pricePerKg)
// and convert it into a format so that for a given fruit name
// retrieval of its color and pricePerKg value is fast

//RUN THROUGH HTML FILE (src given)
let fruitList = [];
let records = 2;
for (let j = 0; j < records; j++) {
	var name = window.prompt("Enter your name: ");
	let fruitName = window.prompt(
		`Enter ${j + 1} th Fruit Name out of ${records}`
		);
        let fruitColor = window.prompt(`Enter ${fruitName}'s Color`);
        let fruitPrice = window.prompt(`Enter ${fruitName}'s Price`);

        fruitList.push([`${fruitName}`, `${fruitColor}`, `${fruitPrice}`]);
      }
      let obj = [];
      for (let i = 0; i < fruitList.length; i++) {
        obj.push({
          fName: `${fruitList[i][0]}`,
          fColor: `${fruitList[i][1]}`,
          fPricePerKg: `${fruitList[i][2]}`,
        });
      }

      obj.forEach((e) => {
	console.log(name);
        console.log(
          `The Fruit's Name Is ${e.fName} , It's Color Is: ${e.fColor} and It's PricePerKg Is:${e.fPricePerKg}`
        );
      });
      console.log(name);
      console.log(obj);