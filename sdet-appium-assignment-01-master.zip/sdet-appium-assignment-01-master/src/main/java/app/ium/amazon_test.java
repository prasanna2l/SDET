package app.ium;
import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.remote.MobilePlatform;

public class amazon_test {
	public static void main(String[] args) throws MalformedURLException, InterruptedException {
		DesiredCapabilities dc = new DesiredCapabilities();
		dc.setCapability(MobileCapabilityType.PLATFORM_NAME, MobilePlatform.ANDROID);
    	//URL url = new URL ("http://127.0.0.1:4723/wd/hub/");
    	//AndroidDriver<WebElement> driver = new AndroidDriver<WebElement>(url,dc);
    	//Launching app
    	dc.setCapability("appPackage", "com.android.chrome"); 
    	dc.setCapability("appActivity", "com.google.android.apps.chrome.Main"); 
    	dc.setCapability("noReset", true);
    	AndroidDriver<MobileElement> driver = new AndroidDriver<MobileElement>(new URL("http://127.0.0.1:4723/wd/hub/"),dc);
    	Thread.sleep(4000);
    	
    	//Open this URL -  www.amazon.in
    	driver.navigate().to("https://www.amazon.in/");
    	Thread.sleep(2000);
    	
    	//Maximize or set size of browser window
    	driver.manage().window().maximize();
    	
    	//Getting the page title and print it
    	String title = driver.getTitle();
    	System.out.println("Title of amazon page : "+title);
    	Thread.sleep(2000);
    	driver.findElementByAccessibilityId("Clear search keywords").sendKeys("mobiles");
    	driver.navigate().back();
    	
    	//Click on menu link
    	//Wish List
    	driver.findElement(By.xpath("//android.view.View[@content-desc=\"Wish List\"]/android.widget.TextView")).click();
    	String menu1 = driver.getTitle();
    	System.out.println(menu1);
    	driver.navigate().back();
    	
    	//Deals
    	driver.findElement(By.xpath("//android.view.View[@content-desc=\"Deals\"]/android.widget.TextView")).click();
    	String menu2 = driver.getTitle();
    	System.out.println(menu2);
    	driver.navigate().back();
    	
    	//Sell
    	driver.findElement(By.xpath("//android.view.View[@content-desc=\"Sell\"]/android.widget.TextView")).click();
    	String menu3 = driver.getTitle();
    	System.out.println(menu3);
    	driver.navigate().back();
    	
    	//livestream
    	driver.findElement(By.xpath("//android.view.View[@content-desc=\"Livestreams\"]/android.widget.TextView")).click();
    	String menu4 = driver.getTitle();
    	System.out.println(menu4);
    	driver.navigate().back();
    	
    	//nav-hamburger-menu
    	driver.findElement(By.id("nav-hamburger-menu"));
    	String menu5 = driver.getTitle();
    	System.out.println(menu5);
    	driver.navigate().back();
    	
    	
    	driver.quit();
	}
}